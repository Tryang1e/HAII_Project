import { useEffect, useRef, useState, useCallback } from 'react';

export interface HandData {
  handedness: 'left' | 'right' | 'both' | 'none';
  status: 'idle' | 'drawing' | 'rotating' | 'zooming';
  position?: { x: number; y: number; z: number };
  gesture?: 'pinch' | 'fist' | 'open';
  drawingPoints?: Array<{ x: number; y: number; z: number }>;
}

export function useWebSocket(url: string = 'ws://localhost:8765') {
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [handData, setHandData] = useState<HandData>({
    handedness: 'none',
    status: 'idle'
  });
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);

  const connect = useCallback(() => {
    try {
      // 기존 연결 정리
      if (wsRef.current) {
        wsRef.current.close();
      }

      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('✅ WebSocket 연결됨');
        setIsConnected(true);
        setConnectionError(null);
        reconnectAttemptsRef.current = 0;
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setHandData(data);
        } catch (error) {
          console.error('데이터 파싱 오류:', error);
        }
      };

      ws.onerror = () => {
        // 오류 로그를 간단하게 처리
        setConnectionError('Python 서버에 연결할 수 없습니다');
        setIsConnected(false);
      };

      ws.onclose = () => {
        console.log('🔌 WebSocket 연결 끊김');
        setIsConnected(false);

        // 자동 재연결 (최대 5회)
        if (reconnectAttemptsRef.current < 5) {
          reconnectAttemptsRef.current += 1;
          const delay = Math.min(1000 * reconnectAttemptsRef.current, 5000);

          console.log(`🔄 ${delay/1000}초 후 재연결 시도 (${reconnectAttemptsRef.current}/5)...`);

          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, delay);
        } else {
          setConnectionError('재연결 실패: Python 서버가 실행 중인지 확인하세요');
        }
      };
    } catch (error) {
      console.error('WebSocket 연결 오류:', error);
      setConnectionError('연결 실패');
      setIsConnected(false);
    }
  }, [url]);

  useEffect(() => {
    connect();

    // 정리
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return { isConnected, handData, connectionError, reconnect: connect };
}
