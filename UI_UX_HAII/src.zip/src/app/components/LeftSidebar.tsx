import { Hand, Move3d, Grid3x3, Maximize } from 'lucide-react';

interface LeftSidebarProps {
  mode: '2d' | '3d';
  onModeChange: (mode: '2d' | '3d') => void;
  isRotateMode: boolean;
  onRotateModeToggle: () => void;
}

export function LeftSidebar({
  mode,
  onModeChange,
  isRotateMode,
  onRotateModeToggle
}: LeftSidebarProps) {
  return (
    <div className="w-16 h-full bg-gray-900 border-r border-gray-700 flex flex-col items-center py-4 gap-3">
      {/* 모드 전환 */}
      <div className="flex flex-col gap-2">
        <button
          onClick={() => onModeChange('2d')}
          className={`p-3 rounded-lg transition-colors ${
            mode === '2d'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          title="평면 모드 (2D Mode)"
        >
          <Grid3x3 size={20} />
        </button>
        <button
          onClick={() => onModeChange('3d')}
          className={`p-3 rounded-lg transition-colors ${
            mode === '3d'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          title="3D 모드 (3D Mode)"
        >
          <Move3d size={20} />
        </button>
      </div>

      <div className="w-8 h-px bg-gray-700 my-2" />

      {/* 회전 모드 */}
      <button
        onClick={onRotateModeToggle}
        className={`p-3 rounded-lg transition-colors ${
          isRotateMode
            ? 'bg-green-600 text-white'
            : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
        }`}
        title="회전 모드 (Rotate Mode)"
      >
        <Hand size={20} />
      </button>

      <div className="flex-1" />

      {/* 확대/축소 안내 */}
      <div className="p-3 bg-gray-800 text-gray-400 rounded-lg" title="핀치로 확대/축소">
        <Maximize size={20} />
      </div>
    </div>
  );
}
