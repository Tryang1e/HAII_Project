import { Brush, Eraser, Undo, Redo, RotateCcw } from 'lucide-react';

interface TopToolbarProps {
  selectedTool: 'brush' | 'eraser';
  onToolChange: (tool: 'brush' | 'eraser') => void;
  selectedColor: string;
  onColorChange: (color: string) => void;
  brushSize: number;
  onBrushSizeChange: (size: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
}

const COLORS = [
  '#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF',
  '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080'
];

const BRUSH_SIZES = [2, 4, 6, 8, 12, 16, 20];

export function TopToolbar({
  selectedTool,
  onToolChange,
  selectedColor,
  onColorChange,
  brushSize,
  onBrushSizeChange,
  onUndo,
  onRedo,
  onClear
}: TopToolbarProps) {
  return (
    <div className="w-full h-16 bg-gray-900 border-b border-gray-700 flex items-center px-4 gap-6">
      {/* 도구 선택 */}
      <div className="flex gap-2">
        <button
          onClick={() => onToolChange('brush')}
          className={`p-3 rounded-lg transition-colors ${
            selectedTool === 'brush'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          title="브러시 (Brush)"
        >
          <Brush size={20} />
        </button>
        <button
          onClick={() => onToolChange('eraser')}
          className={`p-3 rounded-lg transition-colors ${
            selectedTool === 'eraser'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          title="지우개 (Eraser)"
        >
          <Eraser size={20} />
        </button>
      </div>

      <div className="w-px h-8 bg-gray-700" />

      {/* 색상 팔레트 */}
      <div className="flex gap-2 items-center">
        <span className="text-gray-400 text-sm">색상:</span>
        <div className="flex gap-1.5">
          {COLORS.map((color) => (
            <button
              key={color}
              onClick={() => onColorChange(color)}
              className={`w-8 h-8 rounded-md border-2 transition-all ${
                selectedColor === color
                  ? 'border-white scale-110'
                  : 'border-gray-600 hover:border-gray-400'
              }`}
              style={{ backgroundColor: color }}
              title={color}
            />
          ))}
        </div>
      </div>

      <div className="w-px h-8 bg-gray-700" />

      {/* 선 굵기 */}
      <div className="flex gap-3 items-center">
        <span className="text-gray-400 text-sm">굵기:</span>
        <div className="flex gap-2">
          {BRUSH_SIZES.map((size) => (
            <button
              key={size}
              onClick={() => onBrushSizeChange(size)}
              className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                brushSize === size
                  ? 'bg-blue-600'
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
              title={`${size}px`}
            >
              <div
                className="rounded-full bg-white"
                style={{
                  width: `${Math.min(size, 16)}px`,
                  height: `${Math.min(size, 16)}px`
                }}
              />
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1" />

      {/* 편집 기능 */}
      <div className="flex gap-2">
        <button
          onClick={onUndo}
          className="p-3 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors"
          title="되돌리기 (Undo)"
        >
          <Undo size={20} />
        </button>
        <button
          onClick={onRedo}
          className="p-3 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors"
          title="다시실행 (Redo)"
        >
          <Redo size={20} />
        </button>
        <button
          onClick={onClear}
          className="p-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          title="전체 지우기 (Clear)"
        >
          <RotateCcw size={20} />
        </button>
      </div>
    </div>
  );
}
