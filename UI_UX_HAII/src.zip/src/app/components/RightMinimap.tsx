interface RightMinimapProps {
  topViewData?: string;
  sideViewData?: string;
}

export function RightMinimap({ topViewData, sideViewData }: RightMinimapProps) {
  return (
    <div className="w-64 h-full bg-gray-900 border-l border-gray-700 flex flex-col p-4 gap-4">
      {/* Top View (X-Z 평면) */}
      <div className="flex-1 flex flex-col">
        <div className="text-gray-400 text-sm mb-2 font-medium">
          탑 뷰 (Top View)
        </div>
        <div className="flex-1 bg-gray-800 rounded-lg border border-gray-700 relative overflow-hidden">
          <canvas
            id="minimap-top"
            className="w-full h-full"
            style={{ imageRendering: 'pixelated' }}
          />
          {/* X-Z 축 표시 */}
          <div className="absolute bottom-2 left-2 text-xs text-gray-500">
            X-Z 평면
          </div>
        </div>
      </div>

      {/* Side View (Z-Y 평면) */}
      <div className="flex-1 flex flex-col">
        <div className="text-gray-400 text-sm mb-2 font-medium">
          사이드 뷰 (Side View)
        </div>
        <div className="flex-1 bg-gray-800 rounded-lg border border-gray-700 relative overflow-hidden">
          <canvas
            id="minimap-side"
            className="w-full h-full"
            style={{ imageRendering: 'pixelated' }}
          />
          {/* Z-Y 축 표시 */}
          <div className="absolute bottom-2 left-2 text-xs text-gray-500">
            Z-Y 평면
          </div>
        </div>
      </div>

      {/* 좌표 정보 */}
      <div className="bg-gray-800 rounded-lg p-3 border border-gray-700">
        <div className="text-gray-400 text-xs space-y-1">
          <div className="flex justify-between">
            <span>X:</span>
            <span className="text-white font-mono">0.00</span>
          </div>
          <div className="flex justify-between">
            <span>Y:</span>
            <span className="text-white font-mono">0.00</span>
          </div>
          <div className="flex justify-between">
            <span>Z:</span>
            <span className="text-white font-mono">0.00</span>
          </div>
        </div>
      </div>
    </div>
  );
}
