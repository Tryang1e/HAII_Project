interface CanvasAreaProps {
  mode: '2d' | '3d';
}

export function CanvasArea({ mode }: CanvasAreaProps) {
  return (
    <div className="flex-1 bg-gray-950 relative overflow-hidden">
      {/* 메인 캔버스 */}
      <canvas
        id="main-canvas"
        className="absolute inset-0 w-full h-full"
        style={{ touchAction: 'none' }}
      />

      {/* 그리드 배경 (선택적) */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      {/* 모드 표시 */}
      <div className="absolute top-4 left-4 bg-gray-900/80 backdrop-blur-sm px-4 py-2 rounded-lg border border-gray-700">
        <span className="text-gray-300 text-sm font-medium">
          {mode === '2d' ? '평면 모드' : '3D 모드'}
        </span>
      </div>

      {/* 중앙 십자선 (참고용) */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
        <div className="relative">
          <div className="absolute w-20 h-px bg-red-500/30 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute w-px h-20 bg-red-500/30 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
      </div>
    </div>
  );
}
