import { Terminal, Play, Wifi } from 'lucide-react';

interface ConnectionGuideProps {
  isConnected: boolean;
  onDismiss: () => void;
}

export function ConnectionGuide({ isConnected, onDismiss }: ConnectionGuideProps) {
  if (isConnected) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-xl p-6 max-w-2xl w-full shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <Wifi className="text-yellow-500" size={24} />
          <h2 className="text-xl font-bold text-white">Python 서버 연결 가이드</h2>
        </div>

        <div className="space-y-4 text-gray-300">
          <p className="text-sm">
            3D 가상터치 그림판을 사용하려면 Python MediaPipe 서버가 필요합니다.
          </p>

          <div className="bg-gray-800 rounded-lg p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">
                1
              </div>
              <div className="flex-1">
                <p className="font-medium text-white mb-1">필요한 라이브러리 설치</p>
                <div className="bg-gray-950 rounded p-2 font-mono text-xs text-green-400">
                  pip install websockets mediapipe opencv-python
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">
                2
              </div>
              <div className="flex-1">
                <p className="font-medium text-white mb-1">Python 서버 실행</p>
                <div className="bg-gray-950 rounded p-2 font-mono text-xs text-green-400">
                  python your_mediapipe_script.py
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">
                3
              </div>
              <div className="flex-1">
                <p className="font-medium text-white mb-1">WebSocket 서버 포트 확인</p>
                <p className="text-sm text-gray-400">
                  Python 코드에서 <code className="bg-gray-700 px-1 rounded">localhost:8765</code>로 서버가 실행되는지 확인하세요.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-blue-900/30 border border-blue-700 rounded-lg p-4">
            <p className="text-sm text-blue-300">
              <strong>💡 Tip:</strong> 상세한 연동 가이드는 프로젝트의{' '}
              <code className="bg-blue-800 px-1 rounded">INTEGRATION_GUIDE.md</code> 파일을 참고하세요.
            </p>
          </div>
        </div>

        <div className="mt-6 flex gap-3">
          <button
            onClick={onDismiss}
            className="flex-1 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Python 없이 UI만 테스트
          </button>
          <button
            onClick={onDismiss}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Play size={16} />
            확인
          </button>
        </div>
      </div>
    </div>
  );
}
