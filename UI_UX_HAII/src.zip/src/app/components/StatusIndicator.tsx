import { Pencil, Hand, MousePointer2 } from 'lucide-react';

interface StatusIndicatorProps {
  status: 'idle' | 'drawing' | 'rotating' | 'zooming';
  handedness: 'left' | 'right' | 'both' | 'none';
}

export function StatusIndicator({ status, handedness }: StatusIndicatorProps) {
  const getStatusInfo = () => {
    switch (status) {
      case 'drawing':
        return {
          icon: <Pencil size={16} />,
          text: '드로잉 중',
          bgColor: 'bg-blue-600',
          textColor: 'text-white'
        };
      case 'rotating':
        return {
          icon: <Hand size={16} />,
          text: '회전 중',
          bgColor: 'bg-green-600',
          textColor: 'text-white'
        };
      case 'zooming':
        return {
          icon: <MousePointer2 size={16} />,
          text: '확대/축소 중',
          bgColor: 'bg-purple-600',
          textColor: 'text-white'
        };
      default:
        return {
          icon: <MousePointer2 size={16} />,
          text: '대기 중',
          bgColor: 'bg-gray-700',
          textColor: 'text-gray-300'
        };
    }
  };

  const getHandednessText = () => {
    switch (handedness) {
      case 'left':
        return '왼손 인식됨';
      case 'right':
        return '오른손 인식됨';
      case 'both':
        return '양손 인식됨';
      default:
        return '손 감지 안됨';
    }
  };

  const statusInfo = getStatusInfo();

  return (
    <div className="fixed top-20 left-20 z-50 flex flex-col gap-2">
      {/* 상태 표시 */}
      <div
        className={`${statusInfo.bgColor} ${statusInfo.textColor} px-4 py-2 rounded-lg shadow-lg flex items-center gap-2`}
      >
        {statusInfo.icon}
        <span className="font-medium">{statusInfo.text}</span>
      </div>

      {/* 손 인식 상태 */}
      <div className="bg-gray-800 text-gray-300 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
        <Hand size={16} />
        <span className="text-sm">{getHandednessText()}</span>
      </div>
    </div>
  );
}
